package pack1;

public class Sample {
	public void login() {
		int a= 10;
		int b=23;
		
		System.out.println("login sucsessfull "+(a+b));
	}
	public void welcom() {
		System.out.println("Enter in welcome page");
		
	}
	public void kill() {
		System.out.println("broser close successfully");
		
	}

}
