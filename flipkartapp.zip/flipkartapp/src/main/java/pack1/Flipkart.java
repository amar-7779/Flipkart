package pack1;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Flipkart {
	public static String mb = "Mobile";
	public static String url = "https://www.flipkart.com/";
	public static String v2 = "watch";

	static ChromeDriver driver;

	public static void main(String arg[]) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(url);// Enter url
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class=\"b3wTlE\"]")).click();// avoid app popup
		Thread.sleep(2000);

		driver.findElement(By.xpath("//form[@class='lilxh_ header-form-search']//input[@placeholder='Search for Products, Brands and More']")).sendKeys(mb);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']//*[name()='svg']")).click();// enter search button
		Thread.sleep(1000);

		WebElement element = driver.findElement(By.xpath("//div[normalize-space()='IQOO Z10X 5G (Titanium, 128 GB)']"));// select
																														// element
																														// to
																														// scroll
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(2000);
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("Scroll.png"));
		System.out.println("Scrolled successfully and get Screenshort ");
		driver.navigate().back();
		
		System.out.println("one step is success");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//form[@class='lilxh_ header-form-search']//input[@placeholder='Search for Products, Brands and More']")).sendKeys(v2);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='submit']//*[name()='svg']")).click();
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(3000);
		File sre = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sre, new File("meain menu.png"));
		System.out.println("test pass");
		driver.quit();
	}

}
