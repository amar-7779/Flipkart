package pack1;

public class Sample2  {

	public static void main(String[] args) {
		Sample s1=new Sample();
		s1.login();
		s1.welcom();
		s1.kill();

	}

}
